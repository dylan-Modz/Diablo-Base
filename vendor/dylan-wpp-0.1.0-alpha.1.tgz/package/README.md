# Dylan WPP

Cliente independente de WhatsApp Web para Node.js.

> Estado atual: **alpha de protocolo**. A API pública, sessão, Native Flow, codec binário, WebSocket e núcleo Noise já estão separados. Pareamento e criptografia de mensagens precisam ser validados em conta real antes de uma versão estável.

## Instalação

```bash
npm i @dylan/wpp
```

Para testar um pacote local:

```bash
npm i ./dylan-wpp-0.1.0-alpha.1.tgz
```

## Conexão

```js
import makeWASocket, {
  useMultiFileAuthState
} from '@dylan/wpp'

const { state, saveCreds } = await useMultiFileAuthState('./session')

const sock = makeWASocket({
  auth: state,
  connect: false
})

sock.ev.on('creds.update', saveCreds)

sock.ev.on('connection.update', update => {
  console.log(update)
})

await sock.connect()
```

## Código de pareamento

```js
const code = await sock.requestPairingCode('5599999999999')
console.log(code)
```

## Texto

```js
await sock.sendMessage('5599999999999@s.whatsapp.net', {
  text: 'Olá!'
})
```

## Botões

```js
import { button } from '@dylan/wpp'

await sock.sendButtons(jid, {
  text: 'Escolha uma opção',
  buttons: [
    button.quickReply('Menu', '.menu'),
    button.url('Site', 'https://example.com'),
    button.copy('Copiar', 'DYLAN-WPP')
  ]
})
```

Também é possível mandar um tipo novo sem esperar atualização:

```js
button.raw('nome_do_tipo', {
  display_text: 'Abrir',
  qualquer_campo: true
})
```

## Eventos

```js
sock.ev.on('messages.upsert', ({ messages }) => {})
sock.ev.on('messages.update', updates => {})
sock.ev.on('presence.update', update => {})
sock.ev.on('connection.update', update => {})
sock.ev.on('creds.update', saveCreds)
```

## Estrutura

O projeto separa autenticação, Noise, WebSocket, codec de nodes, mensagens, recursos de conta e Native Flow. Isso permite corrigir uma mudança do protocolo em um módulo sem alterar a API usada pelos bots.

## Node.js

Node.js 22.5 ou superior.
