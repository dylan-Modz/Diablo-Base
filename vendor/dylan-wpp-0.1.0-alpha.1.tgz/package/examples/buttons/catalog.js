import { button } from '@dylan/wpp'

export default button.catalog('Catálogo')
