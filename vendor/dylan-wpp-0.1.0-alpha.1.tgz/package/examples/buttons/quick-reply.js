import { button } from '@dylan/wpp'

export default button.quickReply('Menu', '.menu')
