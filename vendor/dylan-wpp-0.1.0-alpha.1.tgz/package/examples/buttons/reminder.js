import { button } from '@dylan/wpp'

export default button.reminder({ display_text: 'Lembrar' })
