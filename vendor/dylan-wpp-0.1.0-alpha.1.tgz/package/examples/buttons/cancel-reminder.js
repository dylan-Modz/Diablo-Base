import { button } from '@dylan/wpp'

export default button.cancelReminder({ display_text: 'Cancelar' })
