import { button } from '@dylan/wpp'

export default button.location({ display_text: 'Localização' })
