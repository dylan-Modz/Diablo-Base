import { button } from '@dylan/wpp'

export default button.url('Site', 'https://example.com')
