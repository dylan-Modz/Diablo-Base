import { button } from '@dylan/wpp'

export default button.reviewAndPay({ display_text: 'Pagar' })
