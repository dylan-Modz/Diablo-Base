import { button } from '@dylan/wpp'

export const buttons = [
  button.quickReply('Ping', '.ping'),
  button.singleSelect('Abrir menu', [{ title: 'Principal', rows: [{ title: 'Ping', id: '.ping' }] }]),
  button.url('Abrir site', 'https://example.com'),
  button.copy('Copiar código', 'DYLAN-WPP'),
  button.call('Ligar', '+5599999999999'),
  button.catalog(),
  button.reminder({ display_text: 'Lembrar' }),
  button.cancelReminder({ display_text: 'Cancelar lembrete' }),
  button.address({ display_text: 'Informar endereço' }),
  button.location({ display_text: 'Enviar localização' }),
  button.webview({ title: 'Abrir página', link: { in_app_webview: true, url: 'https://example.com' } }),
  button.mpm({ display_text: 'Produtos' }),
  button.paymentInfo({ display_text: 'Pagamento' }),
  button.reviewAndPay({ display_text: 'Revisar e pagar' }),
  button.paymentDetails({ display_text: 'Detalhes' }),
  button.greetingCatalog({ display_text: 'Ver catálogo' }),
  button.galaxy({ display_text: 'Galaxy' }),
  button.callPermission({ display_text: 'Permitir ligação' }),
  button.limitedTimeOffer({ display_text: 'Oferta' }),
  button.raw('future_button', { display_text: 'Tipo futuro', custom: true })
]
