import { button } from '@dylan/wpp'

export default button.paymentDetails({ display_text: 'Detalhes' })
