import { button } from '@dylan/wpp'

export default button.address({ display_text: 'Endereço' })
