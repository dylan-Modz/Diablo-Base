import { button } from '@dylan/wpp'

export default button.callPermission({ display_text: 'Permitir' })
