import { button } from '@dylan/wpp'

export default button.call('Ligar', '+5599999999999')
