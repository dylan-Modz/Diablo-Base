import { button } from '@dylan/wpp'

export default button.mpm({ display_text: 'Produtos' })
