import { button } from '@dylan/wpp'

export default button.copy('Copiar', 'DYLAN-WPP')
