import { button } from '@dylan/wpp'

export default button.webview({ title: 'Abrir', link: { in_app_webview: true, url: 'https://example.com' } })
