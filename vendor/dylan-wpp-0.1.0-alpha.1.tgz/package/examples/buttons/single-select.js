import { button } from '@dylan/wpp'

export default button.singleSelect('Abrir menu', [{ title: 'Principal', rows: [{ title: 'Ping', id: '.ping' }] }])
