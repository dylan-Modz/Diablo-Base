import { button } from '@dylan/wpp'

export default button.greetingCatalog({ display_text: 'Ver catálogo' })
