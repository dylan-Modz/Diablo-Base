import { button } from '@dylan/wpp'

export default button.paymentInfo({ display_text: 'Pagamento' })
