import { button } from '@dylan/wpp'

export default button.limitedTimeOffer({ display_text: 'Oferta' })
