import { button } from '@dylan/wpp'

export default button.galaxy({ display_text: 'Galaxy' })
