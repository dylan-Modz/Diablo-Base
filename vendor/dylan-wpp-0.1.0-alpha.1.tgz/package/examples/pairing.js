import makeWASocket, { useMultiFileAuthState } from '@dylan/wpp'

const { state, saveCreds } = await useMultiFileAuthState('./session')
const sock = makeWASocket({ auth: state, connect: false })

sock.ev.on('creds.update', saveCreds)
sock.ev.on('connection.update', update => console.log('conexão:', update))
sock.ev.on('connection.error', error => console.error('erro:', error.message))

await sock.connect()
const code = await sock.requestPairingCode('5599999999999')
console.log('Código:', code)
