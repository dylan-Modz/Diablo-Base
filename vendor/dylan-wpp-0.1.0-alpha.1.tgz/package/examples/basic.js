import makeWASocket, { useMultiFileAuthState } from '@dylan/wpp'

const { state, saveCreds } = await useMultiFileAuthState('./session')
const sock = makeWASocket({ auth: state })

sock.ev.on('creds.update', saveCreds)
sock.ev.on('connection.update', ({ connection }) => console.log(connection))
sock.ev.on('messages.upsert', ({ messages }) => console.log(messages[0]))
