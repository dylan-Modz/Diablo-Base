for (const pre of document.querySelectorAll('pre')) {
  const b = document.createElement('button')
  b.textContent = 'Copiar'
  b.style.cssText = 'position:absolute;right:10px;top:10px;background:#163d24;color:#baf4cc;border:0;border-radius:8px;padding:6px 9px;cursor:pointer'
  b.onclick = async () => { await navigator.clipboard.writeText(pre.innerText.replace(/^Copiar\n/,'')); b.textContent='Copiado'; setTimeout(()=>b.textContent='Copiar',1000) }
  pre.appendChild(b)
}
