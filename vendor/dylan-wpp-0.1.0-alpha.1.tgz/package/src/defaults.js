export const WPP_VERSION = '0.1.0-alpha.1'
export const WEB_SOCKET_URL = 'wss://web.whatsapp.com/ws/chat'
export const WEB_ORIGIN = 'https://web.whatsapp.com'
export const DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140.0.0.0 Safari/537.36'
export const NOISE_PROTOCOL_NAME = 'Noise_XX_25519_AESGCM_SHA256'
export const WA_NOISE_HEADER = Uint8Array.from([87, 65, 6, 3])
export const SERVER_JID = '@s.whatsapp.net'
export const USER_SERVER = 's.whatsapp.net'
export const GROUP_SERVER = 'g.us'
export const NEWSLETTER_SERVER = 'newsletter'
export const STATUS_JID = 'status@broadcast'

export const DisconnectReason = Object.freeze({
  connectionClosed: 428,
  connectionLost: 408,
  connectionReplaced: 440,
  loggedOut: 401,
  restartRequired: 515,
  timedOut: 408,
  badSession: 500,
  multideviceMismatch: 411,
  forbidden: 403,
  unavailableService: 503
})
