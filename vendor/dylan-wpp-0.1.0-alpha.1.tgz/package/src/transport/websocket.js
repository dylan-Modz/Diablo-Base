import WebSocket from 'ws'
import { DEFAULT_USER_AGENT, WEB_ORIGIN, WEB_SOCKET_URL } from '../defaults.js'

export class WppWebSocket {
  constructor(options = {}) {
    this.url = options.url || WEB_SOCKET_URL
    this.origin = options.origin || WEB_ORIGIN
    this.userAgent = options.userAgent || DEFAULT_USER_AGENT
    this.connectTimeoutMs = options.connectTimeoutMs ?? 20_000
    this.ws = null
  }

  open() {
    if (this.ws?.readyState === WebSocket.OPEN) return Promise.resolve()
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.url, {
        origin: this.origin,
        headers: { 'User-Agent': this.userAgent },
        perMessageDeflate: false,
        handshakeTimeout: this.connectTimeoutMs
      })
      this.ws = ws
      const onError = err => { cleanup(); reject(err) }
      const onOpen = () => { cleanup(); resolve() }
      const cleanup = () => { ws.off('error', onError); ws.off('open', onOpen) }
      ws.once('error', onError); ws.once('open', onOpen)
    })
  }

  send(data) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) throw new Error('WebSocket is not open')
    this.ws.send(data)
  }

  close(code = 1000, reason = 'client close') { this.ws?.close(code, reason) }
  on(event, listener) { this.ws?.on(event, listener); return this }
  once(event, listener) { this.ws?.once(event, listener); return this }
  off(event, listener) { this.ws?.off(event, listener); return this }
  get readyState() { return this.ws?.readyState }
}
