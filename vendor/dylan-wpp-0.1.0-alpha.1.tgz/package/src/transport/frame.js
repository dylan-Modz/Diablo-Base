import { readUInt24BE, writeUInt24BE } from '../utils/bytes.js'

export function encodeFrame(payload) {
  const body = Buffer.from(payload)
  if (body.length > 0xffffff) throw new RangeError('Frame too large')
  return Buffer.concat([writeUInt24BE(body.length), body])
}

export class FrameDecoder {
  constructor() { this.buffer = Buffer.alloc(0) }
  push(chunk) {
    this.buffer = Buffer.concat([this.buffer, Buffer.from(chunk)])
    const frames = []
    while (this.buffer.length >= 3) {
      const len = readUInt24BE(this.buffer)
      if (this.buffer.length < len + 3) break
      frames.push(this.buffer.subarray(3, 3 + len))
      this.buffer = this.buffer.subarray(3 + len)
    }
    return frames
  }
}
