const LIST_EMPTY = 0
const LIST_8 = 248
const LIST_16 = 249
const JID_PAIR = 250
const BINARY_8 = 252
const BINARY_20 = 253
const BINARY_32 = 254

class Writer {
  constructor() { this.parts = [] }
  byte(v) { this.parts.push(Buffer.from([v & 255])) }
  bytes(v) { this.parts.push(Buffer.from(v)) }
  list(size) {
    if (size === 0) return this.byte(LIST_EMPTY)
    if (size < 256) { this.byte(LIST_8); this.byte(size); return }
    this.byte(LIST_16); const b = Buffer.alloc(2); b.writeUInt16BE(size); this.bytes(b)
  }
  raw(value) {
    const b = Buffer.from(String(value))
    if (b.length < 256) { this.byte(BINARY_8); this.byte(b.length) }
    else if (b.length < 1 << 20) { this.byte(BINARY_20); this.byte((b.length >>> 16) & 15); this.byte((b.length >>> 8) & 255); this.byte(b.length & 255) }
    else { this.byte(BINARY_32); const n = Buffer.alloc(4); n.writeUInt32BE(b.length); this.bytes(n) }
    this.bytes(b)
  }
  string(value) {
    const s = String(value)
    const at = s.indexOf('@')
    if (at > 0 && at < s.length - 1) {
      this.byte(JID_PAIR); this.raw(s.slice(0, at)); this.raw(s.slice(at + 1)); return
    }
    this.raw(s)
  }
  finish() { return Buffer.concat(this.parts) }
}

export function encodeBinaryNode(node) {
  const w = new Writer(); writeNode(w, node); return w.finish()
}

function writeNode(w, node) {
  const attrs = node?.attrs || {}; const keys = Object.keys(attrs); const hasContent = node?.content != null
  w.list(1 + keys.length * 2 + (hasContent ? 1 : 0)); w.string(node.tag)
  for (const k of keys) { w.string(k); w.string(attrs[k]) }
  if (!hasContent) return
  const c = node.content
  if (Array.isArray(c)) { w.list(c.length); for (const child of c) writeNode(w, child) }
  else if (Buffer.isBuffer(c) || c instanceof Uint8Array) {
    const b = Buffer.from(c); if (b.length < 256) { w.byte(BINARY_8); w.byte(b.length) } else { w.byte(BINARY_32); const n = Buffer.alloc(4); n.writeUInt32BE(b.length); w.bytes(n) } w.bytes(b)
  } else w.raw(c)
}

class Reader {
  constructor(buffer) { this.b = Buffer.from(buffer); this.o = 0 }
  byte() { if (this.o >= this.b.length) throw new Error('Unexpected binary node EOF'); return this.b[this.o++] }
  bytes(n) { const out = this.b.subarray(this.o, this.o + n); this.o += n; return out }
  listSize(tag = this.byte()) {
    if (tag === LIST_EMPTY) return 0
    if (tag === LIST_8) return this.byte()
    if (tag === LIST_16) { const n = this.b.readUInt16BE(this.o); this.o += 2; return n }
    throw new Error(`Invalid list tag ${tag}`)
  }
  readString(tag = this.byte()) {
    if (tag === JID_PAIR) return `${this.readString()}@${this.readString()}`
    let len
    if (tag === BINARY_8) len = this.byte()
    else if (tag === BINARY_20) len = ((this.byte() & 15) << 16) | (this.byte() << 8) | this.byte()
    else if (tag === BINARY_32) { len = this.b.readUInt32BE(this.o); this.o += 4 }
    else throw new Error(`Unsupported string token ${tag}`)
    return this.bytes(len).toString()
  }
  readBytes(tag) {
    let len
    if (tag === BINARY_8) len = this.byte()
    else if (tag === BINARY_20) len = ((this.byte() & 15) << 16) | (this.byte() << 8) | this.byte()
    else if (tag === BINARY_32) { len = this.b.readUInt32BE(this.o); this.o += 4 }
    else throw new Error(`Unsupported binary token ${tag}`)
    return this.bytes(len)
  }
}

export function decodeBinaryNode(input) {
  const r = new Reader(input); return readNode(r)
}

function readNode(r) {
  const size = r.listSize(); if (size === 0) throw new Error('Empty node')
  const tag = r.readString(); const attrs = {}; const attrCount = Math.floor((size - 1) / 2)
  for (let i = 0; i < attrCount; i++) attrs[r.readString()] = r.readString()
  const hasContent = size % 2 === 0
  let content
  if (hasContent) {
    const token = r.byte()
    if (token === LIST_EMPTY || token === LIST_8 || token === LIST_16) {
      const count = r.listSize(token); content = []; for (let i = 0; i < count; i++) content.push(readNode(r))
    } else content = r.readBytes(token)
  }
  return { tag, attrs, ...(content !== undefined ? { content } : {}) }
}

export function child(node, tag) {
  return Array.isArray(node?.content) ? node.content.find(x => x?.tag === tag) : undefined
}
