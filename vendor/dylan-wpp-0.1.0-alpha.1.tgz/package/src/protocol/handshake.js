import { pbBytes, pbMessage, decodeFields } from './protobuf.js'

export function encodeClientHello(ephemeral) {
  const hello = pbBytes(1, ephemeral)
  return pbMessage(2, hello)
}

export function decodeHandshakeMessage(input) {
  const root = decodeFields(input)
  const server = root.get(3)?.[0]?.value
  if (!server) return {}
  const fields = decodeFields(server)
  return {
    serverHello: {
      ephemeral: fields.get(1)?.[0]?.value,
      static: fields.get(2)?.[0]?.value,
      payload: fields.get(3)?.[0]?.value
    }
  }
}

export function encodeClientFinish({ staticText, payload }) {
  const finish = Buffer.concat([pbBytes(1, staticText), pbBytes(2, payload)])
  return pbMessage(4, finish)
}
