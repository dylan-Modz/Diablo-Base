function varint(value) {
  let n = BigInt(value)
  const out = []
  while (n > 0x7fn) { out.push(Number((n & 0x7fn) | 0x80n)); n >>= 7n }
  out.push(Number(n))
  return Buffer.from(out)
}

function key(field, wire) { return varint((BigInt(field) << 3n) | BigInt(wire)) }
export const pbVarint = (field, value) => Buffer.concat([key(field, 0), varint(value)])
export const pbBool = (field, value) => pbVarint(field, value ? 1 : 0)
export const pbFixed32 = (field, value) => {
  const out = Buffer.alloc(5); out[0] = Number((field << 3) | 5); out.writeUInt32LE(value >>> 0, 1); return out
}
export const pbBytes = (field, value) => {
  const body = Buffer.from(value || []); return Buffer.concat([key(field, 2), varint(body.length), body])
}
export const pbString = (field, value) => pbBytes(field, Buffer.from(String(value ?? '')))
export const pbMessage = pbBytes

export function readVarint(buffer, state) {
  let shift = 0n, out = 0n
  for (;;) {
    if (state.offset >= buffer.length) throw new Error('Unexpected protobuf EOF')
    const b = buffer[state.offset++]
    out |= BigInt(b & 0x7f) << shift
    if ((b & 0x80) === 0) return out
    shift += 7n
    if (shift > 70n) throw new Error('Invalid protobuf varint')
  }
}

export function decodeFields(input) {
  const buffer = Buffer.from(input); const state = { offset: 0 }; const fields = new Map()
  while (state.offset < buffer.length) {
    const tag = readVarint(buffer, state)
    const field = Number(tag >> 3n); const wire = Number(tag & 7n)
    let value
    if (wire === 0) value = readVarint(buffer, state)
    else if (wire === 2) {
      const len = Number(readVarint(buffer, state)); value = buffer.subarray(state.offset, state.offset + len); state.offset += len
    } else if (wire === 5) { value = buffer.readUInt32LE(state.offset); state.offset += 4 }
    else throw new Error(`Unsupported protobuf wire type ${wire}`)
    if (!fields.has(field)) fields.set(field, [])
    fields.get(field).push({ wire, value })
  }
  return fields
}
