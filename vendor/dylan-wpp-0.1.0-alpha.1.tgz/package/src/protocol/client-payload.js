import { pbBool, pbFixed32, pbMessage, pbString, pbVarint } from './protobuf.js'

function appVersion([primary = 2, secondary = 3000, tertiary = 0, quaternary = 0, quinary = 0] = []) {
  return Buffer.concat([
    pbVarint(1, primary), pbVarint(2, secondary), pbVarint(3, tertiary),
    pbVarint(4, quaternary), pbVarint(5, quinary)
  ])
}

function userAgent({ version, platform = 14, osVersion = '0.1', manufacturer = '', device = 'Desktop', releaseChannel = 0, language = 'pt', country = 'BR' } = {}) {
  return Buffer.concat([
    pbVarint(1, platform),
    pbMessage(2, appVersion(version)),
    pbString(5, osVersion),
    pbString(6, manufacturer),
    pbString(7, device),
    pbVarint(10, releaseChannel),
    pbString(11, language),
    pbString(12, country)
  ])
}

function webInfo({ subPlatform = 0 } = {}) {
  return pbVarint(4, subPlatform)
}

export function encodeClientPayload(options = {}) {
  const chunks = []
  if (options.username) chunks.push(pbVarint(1, BigInt(options.username)))
  chunks.push(pbBool(3, !!options.passive))
  chunks.push(pbMessage(5, userAgent(options.userAgent)))
  chunks.push(pbMessage(6, webInfo(options.webInfo)))
  if (options.pushName) chunks.push(pbString(7, options.pushName))
  chunks.push(pbFixed32(9, options.sessionId ?? (Math.random() * 0xffffffff) >>> 0))
  chunks.push(pbBool(10, false))
  chunks.push(pbVarint(12, options.connectType ?? 1))
  chunks.push(pbVarint(13, options.connectReason ?? 1))
  chunks.push(pbVarint(16, options.connectAttemptCount ?? 0))
  chunks.push(pbVarint(18, options.device ?? 0))
  chunks.push(pbVarint(20, 0))
  return Buffer.concat(chunks)
}
