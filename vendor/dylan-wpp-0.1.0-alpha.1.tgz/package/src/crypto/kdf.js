import { createHash, createHmac } from 'node:crypto'

export const sha256 = value => createHash('sha256').update(value).digest()
export const hmacSha256 = (key, value) => createHmac('sha256', key).update(value).digest()

export function hkdfSha256(inputKey, salt = Buffer.alloc(32), info = Buffer.alloc(0), length = 32) {
  const prk = hmacSha256(salt, inputKey)
  const chunks = []
  let previous = Buffer.alloc(0)
  let counter = 1
  while (Buffer.concat(chunks).length < length) {
    previous = hmacSha256(prk, Buffer.concat([previous, Buffer.from(info), Buffer.from([counter++])]))
    chunks.push(previous)
  }
  return Buffer.concat(chunks).subarray(0, length)
}
