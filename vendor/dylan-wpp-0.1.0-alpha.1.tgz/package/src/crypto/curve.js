import { createPrivateKey, createPublicKey, diffieHellman, generateKeyPairSync } from 'node:crypto'

const X25519_SPKI_PREFIX = Buffer.from('302a300506032b656e032100', 'hex')
const X25519_PKCS8_PREFIX = Buffer.from('302e020100300506032b656e04220420', 'hex')

export function generateX25519KeyPair() {
  const { publicKey, privateKey } = generateKeyPairSync('x25519')
  const spki = publicKey.export({ type: 'spki', format: 'der' })
  const pkcs8 = privateKey.export({ type: 'pkcs8', format: 'der' })
  return {
    public: Buffer.from(spki.subarray(spki.length - 32)),
    private: Buffer.from(pkcs8.subarray(pkcs8.length - 32))
  }
}

function publicKeyObject(raw) {
  const key = Buffer.from(raw)
  if (key.length !== 32) throw new TypeError('X25519 public key must be 32 bytes')
  return createPublicKey({ key: Buffer.concat([X25519_SPKI_PREFIX, key]), type: 'spki', format: 'der' })
}

function privateKeyObject(raw) {
  const key = Buffer.from(raw)
  if (key.length !== 32) throw new TypeError('X25519 private key must be 32 bytes')
  return createPrivateKey({ key: Buffer.concat([X25519_PKCS8_PREFIX, key]), type: 'pkcs8', format: 'der' })
}

export function x25519(privateKey, publicKey) {
  return diffieHellman({ privateKey: privateKeyObject(privateKey), publicKey: publicKeyObject(publicKey) })
}
