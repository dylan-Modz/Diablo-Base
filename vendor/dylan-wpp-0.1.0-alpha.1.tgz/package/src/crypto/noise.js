import { createCipheriv, createDecipheriv } from 'node:crypto'
import { NOISE_PROTOCOL_NAME, WA_NOISE_HEADER } from '../defaults.js'
import { concatBytes } from '../utils/bytes.js'
import { hkdfSha256, sha256 } from './kdf.js'
import { generateX25519KeyPair, x25519 } from './curve.js'

function nonce(counter) {
  const out = Buffer.alloc(12)
  out.writeUInt32LE(counter >>> 0, 8)
  return out
}

export class NoiseCipherState {
  constructor(key = null) {
    this.key = key ? Buffer.from(key) : null
    this.counter = 0
  }

  setKey(key) { this.key = Buffer.from(key); this.counter = 0 }

  encrypt(plaintext, aad = Buffer.alloc(0)) {
    if (!this.key) return Buffer.from(plaintext)
    const cipher = createCipheriv('aes-256-gcm', this.key, nonce(this.counter++))
    if (aad.length) cipher.setAAD(Buffer.from(aad))
    return Buffer.concat([cipher.update(plaintext), cipher.final(), cipher.getAuthTag()])
  }

  decrypt(ciphertext, aad = Buffer.alloc(0)) {
    if (!this.key) return Buffer.from(ciphertext)
    const data = Buffer.from(ciphertext)
    if (data.length < 16) throw new Error('Invalid Noise ciphertext')
    const body = data.subarray(0, -16)
    const tag = data.subarray(-16)
    const decipher = createDecipheriv('aes-256-gcm', this.key, nonce(this.counter++))
    if (aad.length) decipher.setAAD(Buffer.from(aad))
    decipher.setAuthTag(tag)
    return Buffer.concat([decipher.update(body), decipher.final()])
  }
}

export class NoiseXXClient {
  constructor({ staticKeyPair, prologue = WA_NOISE_HEADER } = {}) {
    this.staticKeyPair = staticKeyPair || generateX25519KeyPair()
    this.ephemeralKeyPair = generateX25519KeyPair()
    const name = Buffer.from(NOISE_PROTOCOL_NAME)
    this.hash = name.length <= 32 ? Buffer.concat([name, Buffer.alloc(32 - name.length)]) : sha256(name)
    this.chainingKey = Buffer.from(this.hash)
    this.cipher = new NoiseCipherState()
    this.mixHash(prologue)
  }

  mixHash(data) { this.hash = sha256(concatBytes(this.hash, data)) }

  mixKey(input) {
    const material = hkdfSha256(input, this.chainingKey, Buffer.alloc(0), 64)
    this.chainingKey = material.subarray(0, 32)
    this.cipher.setKey(material.subarray(32, 64))
  }

  encryptAndHash(data) {
    const encrypted = this.cipher.encrypt(Buffer.from(data), this.hash)
    this.mixHash(encrypted)
    return encrypted
  }

  decryptAndHash(data) {
    const plain = this.cipher.decrypt(Buffer.from(data), this.hash)
    this.mixHash(data)
    return plain
  }

  clientHello() {
    this.mixHash(this.ephemeralKeyPair.public)
    return Buffer.from(this.ephemeralKeyPair.public)
  }

  readServerHello({ ephemeral, static: encryptedStatic, payload }) {
    this.mixHash(ephemeral)
    this.mixKey(x25519(this.ephemeralKeyPair.private, ephemeral))
    const serverStatic = this.decryptAndHash(encryptedStatic)
    this.mixKey(x25519(this.ephemeralKeyPair.private, serverStatic))
    const serverPayload = this.decryptAndHash(payload)
    return { serverStatic, serverPayload }
  }

  clientFinish(payload) {
    const encryptedStatic = this.encryptAndHash(this.staticKeyPair.public)
    // XX: se
    // A chave estática local é misturada contra a efêmera remota no runtime,
    // portanto o socket injeta o remoteEphemeral antes desta etapa.
    if (!this.remoteEphemeral) throw new Error('remoteEphemeral missing')
    this.mixKey(x25519(this.staticKeyPair.private, this.remoteEphemeral))
    const encryptedPayload = this.encryptAndHash(payload)
    const split = hkdfSha256(Buffer.alloc(0), this.chainingKey, Buffer.alloc(0), 64)
    return {
      encryptedStatic,
      encryptedPayload,
      writeKey: split.subarray(0, 32),
      readKey: split.subarray(32, 64)
    }
  }
}
