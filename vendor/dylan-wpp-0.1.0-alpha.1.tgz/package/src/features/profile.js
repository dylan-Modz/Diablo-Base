export function createProfileApi(query) {
  return {
    picture: (jid, type = 'image') => query({ tag: 'iq', attrs: { to: jid, type: 'get', xmlns: 'w:profile:picture' }, content: [{ tag: 'picture', attrs: { type, query: 'url' } }] }),
    status: jid => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'get', xmlns: 'status' }, content: [{ tag: 'status', attrs: { jid } }] }),
    setStatus: text => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' }, content: [{ tag: 'status', attrs: {}, content: Buffer.from(text) }] }),
    setName: name => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'w:profile' }, content: [{ tag: 'name', attrs: {}, content: Buffer.from(name) }] })
  }
}
