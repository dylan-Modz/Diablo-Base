export function createGroupsApi(query) {
  const iq = (type, content) => query({ tag: 'iq', attrs: { to: '@g.us', type, xmlns: 'w:g2' }, content })
  return {
    metadata: jid => iq('get', [{ tag: 'query', attrs: { request: 'interactive', jid } }]),
    create: (subject, participants = []) => iq('set', [{ tag: 'create', attrs: { subject }, content: participants.map(jid => ({ tag: 'participant', attrs: { jid } })) }]),
    participantsUpdate: (jid, participants, action) => iq('set', [{ tag: action, attrs: { jid }, content: participants.map(p => ({ tag: 'participant', attrs: { jid: p } })) }]),
    subject: (jid, subject) => iq('set', [{ tag: 'subject', attrs: { jid, subject } }]),
    description: (jid, description = '') => iq('set', [{ tag: 'description', attrs: { jid }, content: Buffer.from(description) }]),
    setting: (jid, setting) => iq('set', [{ tag: setting, attrs: { jid } }]),
    inviteCode: jid => iq('get', [{ tag: 'invite', attrs: { jid } }]),
    revokeInvite: jid => iq('set', [{ tag: 'invite', attrs: { jid } }]),
    acceptInvite: code => iq('set', [{ tag: 'join', attrs: { code } }]),
    leave: jid => iq('set', [{ tag: 'leave', attrs: {}, content: [{ tag: 'group', attrs: { id: jid } }] }])
  }
}
