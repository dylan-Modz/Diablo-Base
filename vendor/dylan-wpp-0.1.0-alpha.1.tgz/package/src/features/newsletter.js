export function createNewsletterApi(query) {
  const mex = content => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'get', xmlns: 'newsletter' }, content })
  return {
    metadata: jid => mex([{ tag: 'newsletter', attrs: { jid, query: 'metadata' } }]),
    follow: jid => query({ tag: 'iq', attrs: { to: jid, type: 'set', xmlns: 'newsletter' }, content: [{ tag: 'follow', attrs: {} }] }),
    unfollow: jid => query({ tag: 'iq', attrs: { to: jid, type: 'set', xmlns: 'newsletter' }, content: [{ tag: 'unfollow', attrs: {} }] }),
    mute: (jid, muted = true) => query({ tag: 'iq', attrs: { to: jid, type: 'set', xmlns: 'newsletter' }, content: [{ tag: muted ? 'mute' : 'unmute', attrs: {} }] })
  }
}
