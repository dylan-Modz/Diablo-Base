export function createPrivacyApi(query) {
  const block = (jid, action) => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'blocklist' }, content: [{ tag: 'item', attrs: { action, jid } }] })
  return {
    fetch: () => query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'get', xmlns: 'privacy' }, content: [{ tag: 'privacy', attrs: {} }] }),
    block: jid => block(jid, 'block'),
    unblock: jid => block(jid, 'unblock')
  }
}
