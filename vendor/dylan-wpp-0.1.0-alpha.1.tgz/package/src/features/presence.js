export function createPresenceApi(sendNode) {
  return {
    update: (type = 'available', jid) => sendNode(jid ? { tag: 'chatstate', attrs: { to: jid }, content: [{ tag: type, attrs: {} }] } : { tag: 'presence', attrs: { type } }),
    subscribe: jid => sendNode({ tag: 'presence', attrs: { to: jid, type: 'subscribe' } })
  }
}
