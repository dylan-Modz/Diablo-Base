import fs from 'node:fs'
import path from 'node:path'
import { normalizeButton } from './buttons.js'

export function getContentType(message = {}) {
  const keys = ['conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage', 'reactionMessage', 'pollCreationMessage', 'interactiveMessage', 'viewOnceMessage']
  return keys.find(k => message?.[k] != null)
}

export function guessMime(file = '', fallback = 'application/octet-stream') {
  const map = { '.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.gif':'image/gif','.mp4':'video/mp4','.mp3':'audio/mpeg','.ogg':'audio/ogg','.opus':'audio/ogg; codecs=opus','.pdf':'application/pdf','.zip':'application/zip','.txt':'text/plain' }
  return map[path.extname(String(file)).toLowerCase()] || fallback
}

export async function toMediaBytes(value) {
  if (Buffer.isBuffer(value)) return value
  if (value instanceof Uint8Array) return Buffer.from(value)
  if (value instanceof ArrayBuffer) return Buffer.from(value)
  if (typeof value === 'string') return fs.promises.readFile(value)
  if (value?.url) {
    const res = await fetch(value.url)
    if (!res.ok) throw new Error(`Media download failed: ${res.status}`)
    return Buffer.from(await res.arrayBuffer())
  }
  throw new TypeError('Media must be Buffer, Uint8Array, path or { url }')
}

export function interactiveContent(input = {}) {
  return {
    text: input.text || input.body || '',
    footer: input.footer || '',
    title: input.title || '',
    subtitle: input.subtitle || '',
    viewOnce: input.viewOnce !== false,
    buttons: (input.buttons || input.interactiveButtons || []).map(normalizeButton),
    image: input.image,
    video: input.video,
    gifPlayback: !!input.gifPlayback,
    contextInfo: input.contextInfo || undefined,
    messageParamsJson: typeof input.messageParamsJson === 'string' ? input.messageParamsJson : JSON.stringify(input.messageParamsJson || {})
  }
}

export function carouselContent(input = {}) {
  return {
    text: input.text || input.body || '',
    footer: input.footer || '',
    viewOnce: input.viewOnce !== false,
    carouselCardType: input.carouselCardType ?? 1,
    cards: (input.cards || []).map(interactiveContent)
  }
}
