const raw = (name, params = {}) => ({ name, buttonParamsJson: JSON.stringify(params) })

export const button = {
  raw,
  quickReply: (text, id) => raw('quick_reply', { display_text: text, id }),
  singleSelect: (title, sections) => raw('single_select', { title, sections }),
  url: (text, url, merchantUrl = url) => raw('cta_url', { display_text: text, url, merchant_url: merchantUrl }),
  copy: (text, code) => raw('cta_copy', { display_text: text, copy_code: code }),
  call: (text, phoneNumber) => raw('cta_call', { display_text: text, phone_number: phoneNumber }),
  catalog: (text = 'Ver catálogo') => raw('cta_catalog', { display_text: text }),
  reminder: params => raw('cta_reminder', params),
  cancelReminder: params => raw('cta_cancel_reminder', params),
  address: params => raw('address_message', params),
  location: params => raw('send_location', params),
  webview: params => raw('open_webview', params),
  mpm: params => raw('mpm', params),
  paymentInfo: params => raw('payment_info', params),
  reviewAndPay: params => raw('review_and_pay', params),
  paymentDetails: params => raw('wa_payment_transaction_details', params),
  greetingCatalog: params => raw('automated_greeting_message_view_catalog', params),
  galaxy: params => raw('galaxy_message', params),
  callPermission: params => raw('call_permission_request', params),
  limitedTimeOffer: params => raw('limited_time_offer', params)
}

export const supportedButtonNames = Object.freeze([
  'quick_reply', 'single_select', 'cta_url', 'cta_copy', 'cta_call', 'cta_catalog',
  'cta_reminder', 'cta_cancel_reminder', 'address_message', 'send_location', 'open_webview',
  'mpm', 'payment_info', 'review_and_pay', 'wa_payment_transaction_details',
  'automated_greeting_message_view_catalog', 'galaxy_message', 'call_permission_request',
  'limited_time_offer'
])

export function normalizeButton(input) {
  if (!input || typeof input !== 'object') throw new TypeError('Invalid button')
  if (input.name && input.buttonParamsJson != null) return { name: String(input.name), buttonParamsJson: typeof input.buttonParamsJson === 'string' ? input.buttonParamsJson : JSON.stringify(input.buttonParamsJson) }
  const type = input.type || input.name
  const text = input.text || input.title || input.displayText || input.display_text
  if (type === 'quick_reply') return button.quickReply(text, input.id)
  if (type === 'single_select') return button.singleSelect(text || input.title || 'Selecionar', input.sections || [])
  if (type === 'cta_url' || type === 'url') return button.url(text, input.url, input.merchantUrl)
  if (type === 'cta_copy' || type === 'copy') return button.copy(text, input.copyCode || input.code)
  if (type === 'cta_call' || type === 'call') return button.call(text, input.phoneNumber || input.number)
  return raw(type, input.params || input)
}
