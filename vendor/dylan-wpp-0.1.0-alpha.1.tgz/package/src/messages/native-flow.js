import { pbBytes, pbMessage, pbString, pbVarint } from '../protocol/protobuf.js'

// Codificador pequeno e isolado das estruturas interativas utilizadas pelo runtime.
// Os campos ficam centralizados aqui para facilitar ajustes quando o protocolo mudar.
const encodeButton = b => Buffer.concat([pbString(1, b.name), pbString(2, b.buttonParamsJson)])

export function encodeInteractiveMessage(input) {
  const nativeButtons = Buffer.concat((input.buttons || []).map(b => pbMessage(1, encodeButton(b))))
  const nativeFlow = Buffer.concat([nativeButtons, pbString(2, input.messageParamsJson || '{}'), pbVarint(3, 1)])
  const body = input.text ? pbString(1, input.text) : Buffer.alloc(0)
  const footer = input.footer ? pbString(1, input.footer) : Buffer.alloc(0)
  return Buffer.concat([
    body.length ? pbMessage(1, body) : Buffer.alloc(0),
    footer.length ? pbMessage(2, footer) : Buffer.alloc(0),
    pbMessage(4, nativeFlow)
  ])
}

export function encodeMessageContainer({ text, interactive }) {
  if (interactive) return pbMessage(45, encodeInteractiveMessage(interactive))
  if (text != null) return pbString(1, text)
  throw new TypeError('Unsupported message content')
}
