import { EventEmitter } from 'node:events'

export class WppEventEmitter {
  #ee = new EventEmitter()

  on(event, listener) { this.#ee.on(event, listener); return this }
  once(event, listener) { this.#ee.once(event, listener); return this }
  off(event, listener) { this.#ee.off(event, listener); return this }
  removeAllListeners(event) { this.#ee.removeAllListeners(event); return this }
  emit(event, payload) { return this.#ee.emit(event, payload) }
  listenerCount(event) { return this.#ee.listenerCount(event) }

  emitConnection(update) { this.emit('connection.update', update) }
  emitCreds(update) { this.emit('creds.update', update) }
  emitMessage(message, type = 'notify') { this.emit('messages.upsert', { messages: [message], type }) }
  emitMessageUpdate(update) { this.emit('messages.update', Array.isArray(update) ? update : [update]) }
}
