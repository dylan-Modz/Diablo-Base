export type WppButton = { name: string; buttonParamsJson: string | Record<string, unknown> }
export type AuthCreds = {
  noiseKey: { public: Uint8Array; private: Uint8Array }
  identityKey: { public: Uint8Array; private: Uint8Array }
  registrationId: number
  advSecretKey?: Uint8Array | null
  me?: { id: string; name?: string } | null
  pairingCode?: string | null
  registered: boolean
  [key: string]: unknown
}
export type AuthenticationState = {
  creds: AuthCreds
  keys: {
    get(type: string, ids: string[]): Promise<Record<string, unknown>>
    set(data: Record<string, Record<string, unknown>>): Promise<void>
    clear(): Promise<void>
  }
}
export interface SocketConfig {
  auth: AuthenticationState
  connect?: boolean
  queryTimeoutMs?: number
  connectTimeoutMs?: number
  pushName?: string
  browser?: [string, string, string?]
  version?: number[]
  url?: string
}
export interface WppSocket {
  ev: { on(event: string, listener: (...args: any[]) => void): any; once(event: string, listener: (...args: any[]) => void): any; off(event: string, listener: (...args: any[]) => void): any }
  user?: { id: string; name?: string }
  connect(): Promise<void>
  end(): Promise<void>
  logout(): Promise<void>
  requestPairingCode(number: string, options?: Record<string, unknown>): Promise<string>
  sendMessage(jid: string, content: any, options?: any): Promise<any>
  sendButtons(jid: string, input: any, options?: any): Promise<any>
  sendInteractive(jid: string, input: any, options?: any): Promise<any>
  sendCarousel(jid: string, input: any, options?: any): Promise<any>
  sendNode(node: any): Promise<void>
  query(node: any, timeoutMs?: number): Promise<any>
  groupMetadata(jid: string): Promise<any>
  groupCreate(subject: string, participants?: string[]): Promise<any>
  groupParticipantsUpdate(jid: string, participants: string[], action: 'add'|'remove'|'promote'|'demote'): Promise<any>
  groupSubject(jid: string, subject: string): Promise<any>
  groupDescription(jid: string, description: string): Promise<any>
  groupSettingUpdate(jid: string, setting: string): Promise<any>
  groupInviteCode(jid: string): Promise<any>
  groupRevokeInvite(jid: string): Promise<any>
  groupAcceptInvite(code: string): Promise<any>
  groupLeave(jid: string): Promise<any>
  profilePictureUrl(jid: string, type?: string): Promise<any>
  fetchStatus(jid: string): Promise<any>
  updateProfileStatus(text: string): Promise<any>
  updateProfileName(name: string): Promise<any>
  fetchPrivacySettings(): Promise<any>
  updateBlockStatus(jid: string, action: 'block'|'unblock'): Promise<any>
  sendPresenceUpdate(type: string, jid?: string): Promise<any>
  newsletter: Record<string, (...args: any[]) => Promise<any>>
  lowlevel: { sendNode(node: any): Promise<void>; query(node: any, timeoutMs?: number): Promise<any> }
}
export declare function makeWASocket(options: SocketConfig): WppSocket
export default makeWASocket
export declare function useMultiFileAuthState(folder: string): Promise<{ state: AuthenticationState; saveCreds(update?: Partial<AuthCreds>): Promise<void>; clearState(): Promise<void> }>
export declare function useSingleFileAuthState(file: string): Promise<{ state: AuthenticationState; saveCreds(update?: Partial<AuthCreds>): Promise<void>; clearState(): Promise<void> }>
export declare function initAuthCreds(): AuthCreds
export declare const button: {
  raw(name: string, params?: object): WppButton
  quickReply(text: string, id: string): WppButton
  singleSelect(title: string, sections: any[]): WppButton
  url(text: string, url: string, merchantUrl?: string): WppButton
  copy(text: string, code: string): WppButton
  call(text: string, phoneNumber: string): WppButton
  catalog(text?: string): WppButton
  reminder(params: object): WppButton
  cancelReminder(params: object): WppButton
  address(params: object): WppButton
  location(params: object): WppButton
  webview(params: object): WppButton
  mpm(params: object): WppButton
  paymentInfo(params: object): WppButton
  reviewAndPay(params: object): WppButton
  paymentDetails(params: object): WppButton
  greetingCatalog(params: object): WppButton
  galaxy(params: object): WppButton
  callPermission(params: object): WppButton
  limitedTimeOffer(params: object): WppButton
}
export declare const supportedButtonNames: readonly string[]
export declare const DisconnectReason: Readonly<Record<string, number>>
export declare const WPP_VERSION: string
export declare function jidEncode(user: string, server?: string, device?: number): string
export declare function jidDecode(jid: string): { user: string; server: string; device?: number }
export declare function jidNormalizedUser(jid: string): string
export declare function isJidGroup(jid: string): boolean
export declare function isJidNewsletter(jid: string): boolean
export declare function isJidStatusBroadcast(jid: string): boolean
export declare function isJidUser(jid: string): boolean
export declare function generateMessageID(prefix?: string): string
