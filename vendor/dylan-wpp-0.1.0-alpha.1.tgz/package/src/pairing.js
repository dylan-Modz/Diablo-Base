import { createCipheriv, randomBytes, pbkdf2Sync } from 'node:crypto'
import { generateX25519KeyPair, x25519 } from './crypto/curve.js'
import { hkdfSha256 } from './crypto/kdf.js'
import { concatBytes } from './utils/bytes.js'
import { jidEncode, normalizePhone } from './utils/jid.js'

const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTVWXYZ'
function pairingCode() {
  const data = randomBytes(5)
  let bits = 0, value = 0, out = ''
  for (const byte of data) {
    value = (value << 8) | byte
    bits += 8
    while (bits >= 5) {
      out += ALPHABET[(value >>> (bits - 5)) & 31]
      bits -= 5
    }
  }
  if (bits > 0) out += ALPHABET[(value << (5 - bits)) & 31]
  return out.slice(0, 8)
}

function aesGcm(key, nonce, plain) {
  const c = createCipheriv('aes-256-gcm', key, nonce)
  return Buffer.concat([c.update(plain), c.final(), c.getAuthTag()])
}

export function createPairingApi({ query, creds, emitCreds }) {
  let pending = null

  async function requestPairingCode(phone, options = {}) {
    const number = normalizePhone(phone)
    const keyPair = generateX25519KeyPair()
    const salt = randomBytes(32)
    const iv = randomBytes(16)
    const code = String(options.code || pairingCode()).replace(/-/g, '').toUpperCase()
    if (code.length !== 8) throw new TypeError('O código de pareamento deve ter 8 caracteres')
    const key = pbkdf2Sync(Buffer.from(code), salt, 2 << 16, 32, 'sha256')
    const ctr = createCipheriv('aes-256-ctr', key, iv)
    const encryptedPublic = Buffer.concat([ctr.update(keyPair.public), ctr.final()])
    const wrapped = concatBytes(salt, iv, encryptedPublic)
    creds.pairingCode = code
    pending = { jid: jidEncode(number), keyPair, code, pairingRef: null }
    await emitCreds()

    const response = await query({
      tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'md' }, content: [{
        tag: 'link_code_companion_reg',
        attrs: { jid: pending.jid, stage: 'companion_hello', should_show_push_notification: options.showNotification === false ? 'false' : 'true' },
        content: [
          { tag: 'link_code_pairing_wrapped_companion_ephemeral_pub', attrs: {}, content: wrapped },
          { tag: 'companion_server_auth_key_pub', attrs: {}, content: creds.noiseKey.public },
          { tag: 'companion_platform_id', attrs: {}, content: Buffer.from(String(options.platformId ?? 5)) },
          { tag: 'companion_platform_display', attrs: {}, content: Buffer.from(options.platformDisplay || 'Chrome (Windows)') },
          { tag: 'link_code_pairing_nonce', attrs: {}, content: Buffer.from([0]) }
        ]
      }]
    })

    const reg = Array.isArray(response?.content) ? response.content.find(x => x.tag === 'link_code_companion_reg') : null
    const ref = Array.isArray(reg?.content) ? reg.content.find(x => x.tag === 'link_code_pairing_ref')?.content : null
    if (ref) pending.pairingRef = Buffer.from(ref)
    return `${code.slice(0, 4)}-${code.slice(4, 8)}`
  }

  async function handlePrimaryHello(node) {
    if (!pending) return false
    const reg = Array.isArray(node?.content) ? node.content.find(x => x.tag === 'link_code_companion_reg') : null
    if (!reg || reg.attrs?.stage !== 'primary_hello') return false
    const get = tag => Array.isArray(reg.content) ? reg.content.find(x => x.tag === tag)?.content : null
    const wrappedPrimary = get('link_code_pairing_wrapped_primary_ephemeral_pub')
    const primaryIdentity = get('primary_identity_pub')
    const pairingRef = get('link_code_pairing_ref')
    if (!wrappedPrimary || !primaryIdentity || !pairingRef) return false

    // O formato de primary_hello pode mudar. O runtime mantém a etapa isolada para
    // que os testes reais possam ajustar somente este módulo sem quebrar a API pública.
    const primaryWrapped = Buffer.from(wrappedPrimary)
    if (primaryWrapped.length < 80) throw new Error('primary_hello inválido')
    const primarySalt = primaryWrapped.subarray(0, 32)
    const primaryIv = primaryWrapped.subarray(32, 48)
    const primaryEncrypted = primaryWrapped.subarray(48, 80)
    const linkCodeKey = pbkdf2Sync(Buffer.from(pending.code), primarySalt, 2 << 16, 32, 'sha256')
    const decipher = createCipheriv('aes-256-ctr', linkCodeKey, primaryIv)
    const primaryEphemeral = Buffer.concat([decipher.update(primaryEncrypted), decipher.final()])
    const ephemeralShared = x25519(pending.keyPair.private, primaryEphemeral)
    const identityShared = x25519(creds.identityKey.private, primaryIdentity)
    const advRandom = randomBytes(32)
    creds.advSecretKey = hkdfSha256(concatBytes(ephemeralShared, identityShared, advRandom), Buffer.alloc(32), Buffer.from('adv_secret'), 32)

    const bundleSalt = randomBytes(32); const bundleNonce = randomBytes(12)
    const bundleKey = hkdfSha256(ephemeralShared, bundleSalt, Buffer.from('link_code_pairing_key_bundle_encryption_key'), 32)
    const bundle = concatBytes(creds.identityKey.public, primaryIdentity, advRandom)
    const wrappedBundle = concatBytes(bundleSalt, bundleNonce, aesGcm(bundleKey, bundleNonce, bundle))

    await query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'md' }, content: [{
      tag: 'link_code_companion_reg', attrs: { jid: pending.jid, stage: 'companion_finish' }, content: [
        { tag: 'link_code_pairing_wrapped_key_bundle', attrs: {}, content: wrappedBundle },
        { tag: 'companion_identity_public', attrs: {}, content: creds.identityKey.public },
        { tag: 'link_code_pairing_ref', attrs: {}, content: Buffer.from(pairingRef) }
      ]
    }] })
    await emitCreds()
    return true
  }

  return { requestPairingCode, handlePrimaryHello, get pending() { return pending } }
}
