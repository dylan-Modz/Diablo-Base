import { USER_SERVER } from '../defaults.js'

export const digits = value => String(value ?? '').replace(/\D/g, '')

export function jidEncode(user, server = USER_SERVER, device) {
  const left = device == null ? String(user) : `${user}:${device}`
  return `${left}@${server}`
}

export function jidDecode(jid = '') {
  const value = String(jid || '')
  const at = value.indexOf('@')
  if (at < 0) return { user: value, server: '', device: undefined }
  const left = value.slice(0, at)
  const server = value.slice(at + 1)
  const [user, deviceRaw] = left.split(':')
  return { user, server, device: deviceRaw == null ? undefined : Number(deviceRaw) }
}

export function jidNormalizedUser(jid = '') {
  const value = String(jid || '')
  if (!value.includes('@')) return jidEncode(digits(value))
  const { user, server } = jidDecode(value)
  return jidEncode(user, server)
}

export const isJidGroup = jid => String(jid || '').endsWith('@g.us')
export const isJidNewsletter = jid => String(jid || '').endsWith('@newsletter')
export const isJidStatusBroadcast = jid => String(jid || '') === 'status@broadcast'
export const isJidUser = jid => /@(s\.whatsapp\.net|lid)$/.test(String(jid || ''))

export function normalizePhone(number) {
  const out = digits(number)
  if (out.length < 8) throw new TypeError('Número inválido. Use DDI + número.')
  return out
}
