import { randomBytes as nodeRandomBytes } from 'node:crypto'

export const toBuffer = value => {
  if (Buffer.isBuffer(value)) return value
  if (value instanceof Uint8Array) return Buffer.from(value)
  if (value instanceof ArrayBuffer) return Buffer.from(value)
  if (typeof value === 'string') return Buffer.from(value)
  if (value == null) return Buffer.alloc(0)
  throw new TypeError('Expected bytes, ArrayBuffer or string')
}

export const concatBytes = (...items) => Buffer.concat(items.map(toBuffer))
export const randomBytes = size => nodeRandomBytes(size)
export const base64 = value => toBuffer(value).toString('base64')
export const fromBase64 = value => Buffer.from(String(value || ''), 'base64')
export const hex = value => toBuffer(value).toString('hex')

export function writeUInt24BE(value) {
  const out = Buffer.allocUnsafe(3)
  out[0] = (value >>> 16) & 255
  out[1] = (value >>> 8) & 255
  out[2] = value & 255
  return out
}

export function readUInt24BE(buffer, offset = 0) {
  return (buffer[offset] << 16) | (buffer[offset + 1] << 8) | buffer[offset + 2]
}
