import { randomBytes } from './bytes.js'

export function generateMessageID(prefix = '') {
  const random = randomBytes(10).toString('hex').toUpperCase()
  return `${prefix}${random}`
}

let iqCount = 0
export function generateIqId() {
  iqCount = (iqCount + 1) % 1_000_000
  return `${Date.now().toString(36)}-${iqCount.toString(36)}`
}
