import fs from 'node:fs'
import path from 'node:path'
import { initAuthCreds } from './creds.js'

const encode = value => JSON.stringify(value, (_, v) => {
  if (Buffer.isBuffer(v)) return { __wppType: 'Buffer', data: v.toString('base64') }
  if (v instanceof Uint8Array) return { __wppType: 'Uint8Array', data: Buffer.from(v).toString('base64') }
  if (typeof v === 'bigint') return { __wppType: 'BigInt', data: String(v) }
  return v
}, 2)

const decode = text => JSON.parse(text, (_, v) => {
  if (v?.__wppType === 'Buffer' || v?.__wppType === 'Uint8Array') return Buffer.from(v.data, 'base64')
  if (v?.__wppType === 'BigInt') return BigInt(v.data)
  return v
})

function atomicWrite(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 })
  const tmp = `${file}.tmp-${process.pid}-${Date.now()}`
  fs.writeFileSync(tmp, encode(value), { mode: 0o600 })
  fs.renameSync(tmp, file)
  try { fs.chmodSync(file, 0o600) } catch {}
}

export async function useMultiFileAuthState(folder) {
  const root = path.resolve(folder)
  fs.mkdirSync(root, { recursive: true, mode: 0o700 })
  const credsFile = path.join(root, 'creds.json')
  const keysDir = path.join(root, 'keys')
  fs.mkdirSync(keysDir, { recursive: true, mode: 0o700 })

  let creds = fs.existsSync(credsFile) ? decode(fs.readFileSync(credsFile, 'utf8')) : initAuthCreds()

  const keyFile = (type, id) => path.join(keysDir, `${String(type).replace(/[^a-z0-9.-]/gi, '_')}-${String(id).replace(/[^a-z0-9.-]/gi, '_')}.json`)
  const keys = {
    async get(type, ids) {
      const out = {}
      for (const id of ids) {
        const file = keyFile(type, id)
        if (fs.existsSync(file)) out[id] = decode(await fs.promises.readFile(file, 'utf8'))
      }
      return out
    },
    async set(data) {
      for (const [type, values] of Object.entries(data || {})) {
        for (const [id, value] of Object.entries(values || {})) {
          const file = keyFile(type, id)
          if (value == null) await fs.promises.rm(file, { force: true })
          else atomicWrite(file, value)
        }
      }
    },
    async clear() { await fs.promises.rm(keysDir, { recursive: true, force: true }); await fs.promises.mkdir(keysDir, { recursive: true, mode: 0o700 }) }
  }

  const state = { get creds() { return creds }, set creds(value) { creds = value }, keys }
  const saveCreds = async update => { if (update && update !== creds) Object.assign(creds, update); atomicWrite(credsFile, creds) }
  const clearState = async () => { await fs.promises.rm(root, { recursive: true, force: true }) }
  return { state, saveCreds, clearState }
}

export async function useSingleFileAuthState(file) {
  const target = path.resolve(file)
  let data = fs.existsSync(target) ? decode(fs.readFileSync(target, 'utf8')) : { creds: initAuthCreds(), keys: {} }
  const state = {
    get creds() { return data.creds }, set creds(v) { data.creds = v },
    keys: {
      async get(type, ids) { const bucket = data.keys[type] || {}; return Object.fromEntries(ids.filter(id => bucket[id] != null).map(id => [id, bucket[id]])) },
      async set(input) { for (const [type, values] of Object.entries(input || {})) { data.keys[type] ||= {}; for (const [id, value] of Object.entries(values || {})) value == null ? delete data.keys[type][id] : (data.keys[type][id] = value) } atomicWrite(target, data) },
      async clear() { data.keys = {}; atomicWrite(target, data) }
    }
  }
  const saveCreds = async update => { if (update && update !== data.creds) Object.assign(data.creds, update); atomicWrite(target, data) }
  const clearState = async () => { await fs.promises.rm(target, { force: true }) }
  return { state, saveCreds, clearState }
}
