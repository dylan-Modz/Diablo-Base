import { generateKeyPairSync, randomBytes } from 'node:crypto'
import { generateX25519KeyPair } from '../crypto/curve.js'

function ed25519() {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519')
  return {
    public: publicKey.export({ type: 'spki', format: 'der' }),
    private: privateKey.export({ type: 'pkcs8', format: 'der' })
  }
}

export function initAuthCreds() {
  return {
    noiseKey: generateX25519KeyPair(),
    pairingEphemeralKey: null,
    identityKey: generateX25519KeyPair(),
    signingKey: ed25519(),
    signedPreKey: generateX25519KeyPair(),
    registrationId: randomBytes(2).readUInt16BE(0),
    advSecretKey: null,
    me: null,
    account: null,
    pairingCode: null,
    registered: false,
    platform: 'WEB',
    createdAt: Date.now()
  }
}
