import { WppEventEmitter } from './events.js'
import { WppWebSocket } from './transport/websocket.js'
import { FrameDecoder, encodeFrame } from './transport/frame.js'
import { NoiseCipherState, NoiseXXClient } from './crypto/noise.js'
import { encodeClientHello, decodeHandshakeMessage, encodeClientFinish } from './protocol/handshake.js'
import { encodeClientPayload } from './protocol/client-payload.js'
import { decodeBinaryNode, encodeBinaryNode } from './protocol/binary-node.js'
import { generateIqId, generateMessageID } from './utils/id.js'
import { jidEncode, normalizePhone } from './utils/jid.js'
import { interactiveContent, carouselContent } from './messages/content.js'
import { encodeMessageContainer } from './messages/native-flow.js'
import { createGroupsApi } from './features/groups.js'
import { createProfileApi } from './features/profile.js'
import { createPrivacyApi } from './features/privacy.js'
import { createPresenceApi } from './features/presence.js'
import { createNewsletterApi } from './features/newsletter.js'
import { createPairingApi } from './pairing.js'
import { WA_NOISE_HEADER } from './defaults.js'

const deferred = () => { let resolve, reject; const promise = new Promise((r, j) => { resolve = r; reject = j }); return { promise, resolve, reject } }

export function makeWASocket(options = {}) {
  if (!options.auth?.creds || !options.auth?.keys) throw new TypeError('auth state is required')
  const ev = new WppEventEmitter()
  const auth = options.auth
  const transport = new WppWebSocket(options)
  const pending = new Map()
  const frameDecoder = new FrameDecoder()
  let noise = null
  let readCipher = null
  let writeCipher = null
  let connected = false
  let handshakeDone = false

  const saveCreds = async () => { ev.emitCreds(auth.creds) }

  function settle(node) {
    const id = node?.attrs?.id
    if (!id || !pending.has(id)) return false
    const item = pending.get(id); pending.delete(id)
    if (node.attrs?.type === 'error') item.reject(Object.assign(new Error(`IQ ${id} failed`), { node }))
    else item.resolve(node)
    return true
  }

  async function handleNode(node) {
    if (settle(node)) return
    if (node.tag === 'notification') {
      await pairing.handlePrimaryHello(node).catch(err => ev.emit('connection.error', err))
      ev.emit('notification', node)
      return
    }
    if (node.tag === 'message') {
      ev.emitMessage({ key: { remoteJid: node.attrs?.from, id: node.attrs?.id, fromMe: false, participant: node.attrs?.participant }, message: node, messageTimestamp: Number(node.attrs?.t || 0) })
      return
    }
    if (node.tag === 'receipt') ev.emit('message-receipt.update', node)
    else if (node.tag === 'presence') ev.emit('presence.update', node)
    else if (node.tag === 'chatstate') ev.emit('presence.update', node)
    else ev.emit('node', node)
  }

  function processTransportFrame(frame) {
    try {
      const plain = readCipher ? readCipher.decrypt(frame) : frame
      const node = decodeBinaryNode(plain)
      handleNode(node).catch(err => ev.emit('connection.error', err))
    } catch (error) { ev.emit('connection.error', error) }
  }

  async function handleRaw(data) {
    for (const frame of frameDecoder.push(data)) {
      if (!handshakeDone) {
        try {
          const decoded = decodeHandshakeMessage(frame)
          if (!decoded.serverHello?.ephemeral) continue
          noise.remoteEphemeral = Buffer.from(decoded.serverHello.ephemeral)
          const { serverPayload } = noise.readServerHello(decoded.serverHello)
          ev.emit('handshake.server', { payload: serverPayload })
          const payload = encodeClientPayload({
            username: auth.creds.me?.id ? normalizePhone(auth.creds.me.id) : undefined,
            passive: !!auth.creds.registered,
            pushName: auth.creds.me?.name || options.pushName || 'Dylan WPP',
            userAgent: { version: options.version || [2, 3000, 0], device: options.browser?.[0] || 'Chrome', osVersion: options.browser?.[1] || 'Windows' }
          })
          const finish = noise.clientFinish(payload)
          writeCipher = new NoiseCipherState(finish.writeKey)
          readCipher = new NoiseCipherState(finish.readKey)
          transport.send(encodeFrame(encodeClientFinish({ staticText: finish.encryptedStatic, payload: finish.encryptedPayload })))
          handshakeDone = true
          connected = true
          ev.emitConnection({ connection: 'open', isNewLogin: !auth.creds.registered })
        } catch (error) { ev.emit('connection.error', error) }
      } else processTransportFrame(frame)
    }
  }

  async function connect() {
    ev.emitConnection({ connection: 'connecting' })
    await transport.open()
    noise = new NoiseXXClient({ staticKeyPair: auth.creds.noiseKey, prologue: WA_NOISE_HEADER })
    const hello = encodeClientHello(noise.clientHello())
    transport.ws.on('message', handleRaw)
    transport.ws.on('close', (code, reason) => { connected = false; ev.emitConnection({ connection: 'close', lastDisconnect: { error: new Error(String(reason || 'socket closed')), code } }) })
    transport.ws.on('error', error => ev.emit('connection.error', error))
    transport.send(Buffer.concat([Buffer.from(WA_NOISE_HEADER), encodeFrame(hello)]))
  }

  async function sendNode(node) {
    if (!connected || !writeCipher) throw new Error('Socket not connected')
    const encoded = encodeBinaryNode(node)
    transport.send(encodeFrame(writeCipher.encrypt(encoded)))
  }

  async function query(node, timeoutMs = options.queryTimeoutMs || 30_000) {
    node.attrs ||= {}; node.attrs.id ||= generateIqId()
    const d = deferred(); pending.set(node.attrs.id, d)
    const timer = setTimeout(() => { if (pending.delete(node.attrs.id)) d.reject(new Error(`IQ timeout: ${node.attrs.id}`)) }, timeoutMs)
    try { await sendNode(node); return await d.promise } finally { clearTimeout(timer) }
  }

  const pairing = createPairingApi({ query, creds: auth.creds, emitCreds: saveCreds })
  const groups = createGroupsApi(query)
  const profile = createProfileApi(query)
  const privacy = createPrivacyApi(query)
  const presence = createPresenceApi(sendNode)
  const newsletter = createNewsletterApi(query)

  async function sendMessage(jid, content, sendOptions = {}) {
    if (typeof content === 'string') content = { text: content }
    let proto
    if (content.buttons || content.interactiveButtons) proto = encodeMessageContainer({ interactive: interactiveContent(content) })
    else if (content.carousel) {
      // Carrossel fica exposto na API pública; o encapsulamento completo é mantido em rawMessage
      // até a validação dos campos do cliente atual.
      proto = encodeMessageContainer({ interactive: interactiveContent({ text: content.text || '', buttons: content.buttons || [] }) })
    } else if (content.text != null) proto = encodeMessageContainer({ text: content.text })
    else if (content.rawMessage) proto = Buffer.from(content.rawMessage)
    else throw new TypeError('Unsupported content. Use text, buttons/interactiveButtons or rawMessage.')

    const id = sendOptions.messageId || generateMessageID('3EB0')
    const node = { tag: 'message', attrs: { to: jid, type: 'text', id }, content: [{ tag: 'enc', attrs: { v: '2', type: 'msg' }, content: proto }] }
    await sendNode(node)
    return { key: { remoteJid: jid, fromMe: true, id }, message: content }
  }

  const sock = {
    ev,
    auth,
    connect,
    async end() { transport.close() },
    async logout() { if (auth.creds.me?.id) await query({ tag: 'iq', attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'md' }, content: [{ tag: 'remove-companion-device', attrs: { jid: auth.creds.me.id, reason: 'user_initiated' } }] }); transport.close() },
    requestPairingCode: (number, pairOptions) => pairing.requestPairingCode(number, pairOptions),
    sendNode,
    query,
    sendMessage,
    sendInteractive: (jid, input, sendOptions) => sendMessage(jid, { ...interactiveContent(input), buttons: input.buttons || input.interactiveButtons }, sendOptions),
    sendButtons: (jid, input, sendOptions) => sendMessage(jid, { ...input, buttons: input.buttons || input.interactiveButtons }, sendOptions),
    sendCarousel: (jid, input, sendOptions) => sendMessage(jid, { carousel: carouselContent(input), text: input.text }, sendOptions),
    groupMetadata: groups.metadata,
    groupCreate: groups.create,
    groupParticipantsUpdate: groups.participantsUpdate,
    groupSubject: groups.subject,
    groupDescription: groups.description,
    groupSettingUpdate: groups.setting,
    groupInviteCode: groups.inviteCode,
    groupRevokeInvite: groups.revokeInvite,
    groupAcceptInvite: groups.acceptInvite,
    groupLeave: groups.leave,
    profilePictureUrl: profile.picture,
    fetchStatus: profile.status,
    updateProfileStatus: profile.setStatus,
    updateProfileName: profile.setName,
    fetchPrivacySettings: privacy.fetch,
    updateBlockStatus: (jid, action) => action === 'block' ? privacy.block(jid) : privacy.unblock(jid),
    sendPresenceUpdate: (type, jid) => presence.update(type, jid),
    presenceSubscribe: presence.subscribe,
    newsletter,
    lowlevel: { sendNode, query },
    raw: { transport, pairing, groups, profile, privacy, presence }
  }

  Object.defineProperty(sock, 'user', { enumerable: true, get: () => auth.creds.me || undefined })
  if (options.connect !== false) queueMicrotask(() => connect().catch(error => ev.emit('connection.error', error)))
  return sock
}

export default makeWASocket
